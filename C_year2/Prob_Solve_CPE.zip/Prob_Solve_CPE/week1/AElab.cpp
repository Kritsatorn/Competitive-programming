#include <bits/stdc++.h>
using namespace std;
int main(int argc, char const *argv[])
{
  int n,l,min=999999,count=0;
  char arr[1010];
  cin >> arr ;
  if( strcmp( arr,strrev(arr)))


}
