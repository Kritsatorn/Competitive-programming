#include<bits/stdc++.h>
using namespace std;
int N , M ;
main() {
  scanf("%d %d",&N,&M) ;
  
}